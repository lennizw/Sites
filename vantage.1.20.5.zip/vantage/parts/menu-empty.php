<?php
/**
 * Part Name: Empty Menu
 */
?>
<nav class="site-navigation main-navigation primary">
	<div class="full-container">
	</div>
</nav><!-- .site-navigation .main-navigation -->
