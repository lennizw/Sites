<h3><?php _e( 'Lightning Fast Support', 'vantage' ) ?></h3>
<p>
	<?php printf( __( "As a Vantage user, you'll get fast, friendly support on our own %ssupport forums%s.", 'vantage' ), '<a href="https://siteorigin.com/thread/">', '</a>' ) ?>
	<?php printf( __( "You can also read through the %sVantage documentation%s to get to know it even faster.", 'vantage' ), '<a href="https://siteorigin.com/vantage-documentation/">', '</a>' ) ?>
</p>