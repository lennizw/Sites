<?php
return json_decode( '{
	"b7122312e4008f8f2c76911080bca01a": {
		"name": "Andrew Misplon",
		"email": "b7122312e4008f8f2c76911080bca01a",
		"loc": 5061,
		"score": 86.66669853790476,
		"percent": 61.07632892777309
	},
	"5cff8d4385a469d1baab761889ad3161": {
		"name": "Alex S",
		"email": "5cff8d4385a469d1baab761889ad3161",
		"loc": 1623,
		"score": 51.853942476244214,
		"percent": 36.54285325632623
	},
	"85ce7a450a7ee4895f3bd823505e2e12": {
		"name": "adiraomj",
		"email": "85ce7a450a7ee4895f3bd823505e2e12",
		"loc": 1584,
		"score": 1.9998136507113773,
		"percent": 1.4093219008645956
	},
	"43c0e7220c23bd6636cf5469be6e9612": {
		"name": "Braam Genis",
		"email": "43c0e7220c23bd6636cf5469be6e9612",
		"loc": 161,
		"score": 0.6189714572312497,
		"percent": 0.4362056586501281
	},
	"36639e6e074b731b093bde5a77305179": {
		"name": "Braam Genis",
		"email": "36639e6e074b731b093bde5a77305179",
		"loc": 575,
		"score": 0.24403405445646836,
		"percent": 0.1719772926742167
	},
	"be6a5d2323cfe9ec8246b7a677dbc65b": {
		"name": "Aaron Evans",
		"email": "be6a5d2323cfe9ec8246b7a677dbc65b",
		"loc": 22,
		"score": 0.17072629327544409,
		"percent": 0.12031536242435673
	},
	"9e7a3b2d24c2b15c53209ba8e7b4e724": {
		"name": "Kevin Batdorf",
		"email": "9e7a3b2d24c2b15c53209ba8e7b4e724",
		"loc": 22,
		"score": 0.15359274731982417,
		"percent": 0.10824089661293693
	},
	"d1bea7e3f82e561c135bf5a3d4f9f896": {
		"name": "SiteOrigin Support",
		"email": "d1bea7e3f82e561c135bf5a3d4f9f896",
		"loc": 13,
		"score": 0.10001528058356697,
		"percent": 0.07048342994228396
	},
	"d203744279876c5eda043108e2611648": {
		"name": "Alex S",
		"email": "d203744279876c5eda043108e2611648",
		"loc": 19,
		"score": 0.06238061237650325,
		"percent": 0.04396127768218705
	},
	"a885c7bd5442dd2acd8c3e42001332c6": {
		"name": "Alex S",
		"email": "a885c7bd5442dd2acd8c3e42001332c6",
		"loc": 18,
		"score": 0.02454241071024652,
		"percent": 0.01729568997674382
	},
	"07294cc1dd7658895e44c559dfffd76f": {
		"name": "gpriday",
		"email": "07294cc1dd7658895e44c559dfffd76f",
		"loc": 18,
		"score": 0.004280109502350144,
		"percent": 0.003016307073219043
	}
}', true );